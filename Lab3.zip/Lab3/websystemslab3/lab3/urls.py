from django.urls import path
from . import views

urlpatterns = [
    path('', views.log_entry, name='log_entry'),
    path('list/', views.log_list, name='log_list'),
]