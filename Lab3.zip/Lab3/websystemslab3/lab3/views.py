from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect
from .models import LogEntry
from .forms import LogEntryForm

def log_entry(request):
    if request.method == 'POST':
        form = LogEntryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('log_list')
    else:
        form = LogEntryForm()
    return render(request, 'lab3/log_entry.html', {'form': form})

def log_list(request):
    entries = LogEntry.objects.all().order_by('-timestamp')
    return render(request, 'lab3/log_list.html', {'entries': entries})